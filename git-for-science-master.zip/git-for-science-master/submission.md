Article Type: Education

Title - A quick introduction to version control with Git and GitHub

Abstract: NA

Many Education articles do not have an abstract, e.g. [Bassi 2007][bassi2007] and [Brazas et al. 2014][brazas2014].

[bassi2007]: http://journals.plos.org/ploscollections/article?id=10.1371/journal.pcbi.0030199
[brazas2014]: http://journals.plos.org/ploscollections/article?id=10.1371/journal.pcbi.1003510

Classifications:

*  20.330.70: Software development
*  20.330: Software engineering
*  20: Computer and information sciences
*  20.330.80: Software tools

Competing Interest

The authors have declared that no competing interests exist.

Financial Disclosure

JDB is supported by National Institutes of Health grant AI087658 awarded to Yoav Gilad.
The funders had no role in study design, data collection and analysis, decision to publish, or preparation of the manuscript.

Previous Interactions

B. F. Francis Ouellette invited us via email to write this article for the Education collection.

Collections: Education

Have you been invited to submit to a PLOS Special Collection? No
